﻿namespace Bonus2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Plane plane1 = new Plane("Boeing", "393", 30, "Cargo", "00102");
            Plane plane2 = new Plane("Honda", "000", 10, "AirBus", "12345");
            Plane plane3 = new Plane("Delta", "000", 50, "Military", "99999");
            Plane plane4 = new Plane("United", "000", 29, "test", "12345");
            Plane plane5 = new Plane("Air Canada", "000", 80, "passenger", "34512");
            Plane plane6 = new Plane();
            List<Plane> planes = new List<Plane>();
            planes.Add(plane1);
            planes.Add(plane2);
            planes.Add(plane3);
            planes.Add(plane4);
            planes.Add(plane5);
            planes.Add(plane6);
            foreach (Plane plane in planes)
                Console.WriteLine(plane.ToString());

            Random rand = new Random();
            int num = rand.Next(1, 90);
            Console.WriteLine($"\nRandom passenger number: {num}");
            foreach (Plane plane in planes)
                Console.WriteLine($"\nPlane: plane{planes.IndexOf(plane)+1}, Passengers: {num}, Capacity: {plane.Capacity}, Has_Capacity: {plane.HasCapacity(num)}");

            }

        public class Plane
        {
            public string Manufactory { get; set; }
            public string Model { get; set; }
            public int Capacity { get; set; }
            public string Type { get; set; }
            public string SerialNumber { get; set; }

            public Plane()
            {
                Manufactory = "unknown";
                Model = "unknown";
                Capacity = 0;
                Type = "unassigned";
                SerialNumber = "00000";
            }
            public Plane(string manufactory, string model, int capacity, string type, string serialNumber)
            {
                Manufactory = manufactory;
                Model = model;
                Capacity = capacity;
                if (type.ToLower() == "cargo" || type.ToLower() == "military" || type.ToLower() == "passenger")
                    Type = type;
                else
                {
                    Type = "unassigned";
                }
                SerialNumber = serialNumber;
            }

            public bool HasCapacity(int number)
            {
                if (number <= Capacity)
                    return true;
                else
                    return false;
            }
            public override string ToString()
            {
                return $"Manufactory: {Manufactory}, Model: {Model}, Capacity: {Capacity}, Type: {Type}, Serial Number: {SerialNumber}";
            }
        }
    }
}